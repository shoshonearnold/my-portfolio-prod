# number-genie
a number guessing game built with C# and .NET
